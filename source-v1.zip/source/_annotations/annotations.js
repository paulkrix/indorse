{
  "comments" : [
    {
      "el": "#annotation-css-selector",
      "title" : "Annotation title",
      "comment": "Annotation description"
    }
  ]
}
