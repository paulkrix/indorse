var Genesis = (function( my, $ ) {

    //initialise
    jQuery(document).ready( function() {
        console.log( "Genesis online" );
    });

    // -------
    // 1. Steps

    // *. Public variables and functions
    // -----

    // 1. Steps
    // --------

    var Steps = function( _element ) {
        this.$element = $( _element );
        this.registerHandlers();
    }
    Steps.prototype.$element = null;
    Steps.prototype.open = null;

    Steps.prototype.registerHandlers = function() {
        var steps = this;
        console.log( "registering handlers", this.$element );
        this.$element.find( '.steps__step' ).on('click', function() {
            var index = $( this ).index();
            console.log( "index", $( this ).index() );
            console.log( "clicked", this );
            console.log( "image", $( this ).find( '.steps__step--image' ) );
            console.log( "meta", $( this ).find( '.steps__step--meta' ) );
            steps.open( index );
        });
    }

    Steps.prototype.open = function( index ) {
        this.$element.addClass('owl-carousel');
        this.$element.owlCarousel({
          items: 1,
          startPosition: index,
          mouseDrag: false,
          touchDrag: false,
          pullDrag: false,
          nav: true,
          navText: [ 'PREV', 'NEXT' ]
        });
        // this.$element.trigger( 'to.owl.carousel', index );
    }

    // *. Public variables and functions
    // --------

    my.Steps = Steps;
    return my;

}( Genesis || {}, jQuery ));
